"""
Testes de validação do pipeline — garantem que cada requisito do exercício
continua atendido após qualquer alteração no código.

Execução:
    python -m pytest tests/ -v
    (ou simplesmente: python tests/test_pipeline.py)
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from pipeline import (  # noqa: E402
    ENCODING_LEGADO,
    FUSO_HORARIO,
    LIMIAR_ZSCORE,
    RISCO_DICT,
    adicionar_rastreabilidade,
    calcular_zscore_por_grupo,
    carregar_transacoes,
    construir_pivot_risco,
    detectar_anomalias,
    enriquecer_temporalmente,
    filtrar_alto_valor_sp_rj,
    imputar_valores_ausentes,
    mapear_risco,
    remover_duplicatas,
)


def _base_tratada() -> pd.DataFrame:
    df = carregar_transacoes()
    df = imputar_valores_ausentes(df)
    df = adicionar_rastreabilidade(df)
    df = enriquecer_temporalmente(df)
    df, _ = remover_duplicatas(df)
    return mapear_risco(df)


# --- Etapa 1 ---------------------------------------------------------------

def test_leitura_usa_encoding_legado():
    """O CSV deve ser lido em latin1 sem corromper caracteres."""
    df = carregar_transacoes()
    assert len(df) == 1015, "Esperados 1.015 registros brutos (1.000 + 15 duplicados)"
    assert set(df.columns) >= {
        "id_cliente", "data_transacao", "valor", "origem", "estado_cliente"
    }
    assert ENCODING_LEGADO == "latin1"


def test_imputacao_pela_mediana_do_estado():
    """Nenhum NaN pode sobrar e os valores imputados devem ser a mediana do estado."""
    bruto = carregar_transacoes()
    assert bruto["valor"].isna().any(), "O arquivo de teste precisa conter NaN"

    medianas = bruto.groupby("estado_cliente", observed=True)["valor"].median()
    tratado = imputar_valores_ausentes(bruto)

    assert tratado["valor"].isna().sum() == 0

    imputados = tratado.loc[bruto["valor"].isna()]
    esperado = imputados["estado_cliente"].map(medianas).astype(float)
    assert np.allclose(imputados["valor"].to_numpy(), esperado.to_numpy())


def test_coluna_plataforma_estatica():
    df = adicionar_rastreabilidade(carregar_transacoes())
    assert (df["plataforma"] == "Mobile").all()


# --- Etapa 2 ---------------------------------------------------------------

def test_datetime_com_fuso_e_colunas_de_calendario():
    df = enriquecer_temporalmente(adicionar_rastreabilidade(carregar_transacoes()))

    assert isinstance(df["data_transacao"].dtype, pd.DatetimeTZDtype)
    assert str(df["data_transacao"].dt.tz) == FUSO_HORARIO
    assert {"dia_semana", "mes", "mes_nome"} <= set(df.columns)
    assert df["mes"].between(1, 12).all()
    assert df["dia_semana"].notna().all()


def test_duplicatas_removidas_mantendo_primeira():
    df = enriquecer_temporalmente(adicionar_rastreabilidade(
        imputar_valores_ausentes(carregar_transacoes())))
    dedup, removidas = remover_duplicatas(df)

    assert removidas == 15
    assert len(dedup) == 1000
    # A primeira ocorrência deve ter sido preservada.
    assert dedup.iloc[0]["id_cliente"] == df.iloc[0]["id_cliente"]


# --- Etapa 3 ---------------------------------------------------------------

def test_filtro_bitwise():
    """Todo registro filtrado precisa satisfazer as três condições simultâneas."""
    filtrado = filtrar_alto_valor_sp_rj(_base_tratada())

    assert not filtrado.empty
    assert (filtrado["mes"] == 9).all()
    assert filtrado["estado_cliente"].isin(["SP", "RJ"]).all()
    assert (filtrado["valor"] > 5_000).all()


# --- Etapa 4 ---------------------------------------------------------------

def test_map_de_risco():
    df = _base_tratada()
    assert df["nivel_risco"].isna().sum() == 0
    for cliente, risco in RISCO_DICT.items():
        subset = df.loc[df["id_cliente"] == cliente, "nivel_risco"]
        if not subset.empty:
            assert (subset == risco).all()


def test_pivot_table_com_margens():
    pivot = construir_pivot_risco(_base_tratada())

    assert "TOTAL" in pivot.index, "Falta a linha de subtotal (margins=True)"
    assert "TOTAL" in pivot.columns, "Falta a coluna de subtotal (margins=True)"

    # O subtotal geral deve bater com a soma das categorias.
    categorias = [c for c in pivot.columns if c != "TOTAL"]
    assert np.isclose(
        pivot.loc["TOTAL", "TOTAL"], pivot.loc["TOTAL", categorias].sum()
    )


# --- Etapa 5 ---------------------------------------------------------------

def test_zscore_por_estado_e_anomalias():
    df = _base_tratada()
    z = calcular_zscore_por_grupo(df)

    # Dentro de cada estado, o Z-Score tem média ~0 e desvio ~1.
    por_estado = pd.DataFrame({"estado": df["estado_cliente"], "z": z})
    resumo = por_estado.groupby("estado", observed=True)["z"].agg(["mean", "std"])
    assert np.allclose(resumo["mean"].to_numpy(), 0, atol=1e-9)
    assert np.allclose(resumo["std"].to_numpy(), 1, atol=1e-9)

    _, anomalias = detectar_anomalias(df)
    assert (anomalias["z_score"] > LIMIAR_ZSCORE).all()
    assert len(anomalias) < len(df) * 0.10, "Taxa de anomalias implausível"


if __name__ == "__main__":
    testes = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    falhas = 0
    for teste in testes:
        try:
            teste()
            print(f"  PASSOU  {teste.__name__}")
        except AssertionError as erro:
            falhas += 1
            print(f"  FALHOU  {teste.__name__}: {erro}")
    print(f"\n{len(testes) - falhas}/{len(testes)} testes aprovados.")
    sys.exit(1 if falhas else 0)
