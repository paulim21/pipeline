"""
Pipeline de Análise de Transações Financeiras — Fintech
=======================================================

Pipeline de ponta a ponta que ingere os logs brutos (`transacoes.csv` e
`cotacoes.csv`), limpa, transforma, consolida e gera um relatório visual
com métricas de desempenho e detecção estatística de anomalias.

Etapas (na ordem do enunciado):
    1. Ingestão, performance e limpeza
    2. Engenharia de dados e alinhamento temporal
    3. Operações vetorizadas e filtros bitwise
    4. Cruzamento de dados (.map) e agregação (pivot_table)
    5. Detecção estatística de outliers (Z-Score por estado)
    6. Visualização gráfica orientada a objetos (Matplotlib)

Bônus: consolidação com as cotações diárias (valores convertidos para USD).

Execução:
    python src/pipeline.py
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # backend não interativo: permite rodar em CI / servidor

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# Configuração
# --------------------------------------------------------------------------- #

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"

ARQUIVO_TRANSACOES = DATA_DIR / "transacoes.csv"
ARQUIVO_COTACOES = DATA_DIR / "cotacoes.csv"

ENCODING_LEGADO = "latin1"          # encoding legado do arquivo de transações
FUSO_HORARIO = "America/Sao_Paulo"  # fuso de negócio da fintech
LIMIAR_ZSCORE = 2.5                 # acima disso a transação é potencial anomalia
JANELA_MEDIA_MOVEL = 7              # dias da média móvel de suavização

# Dicionário de categorias de risco fornecido pela área de Crédito.
RISCO_DICT = {
    "C100": "Baixo",
    "C101": "Alto",
    "C102": "Médio",
    "C103": "Baixo",
    "C104": "Alto",
}

# Tradução dos nomes de calendário: independe do locale instalado na máquina
# (usar `locale` quebraria o pipeline em containers sem pt_BR.UTF-8).
DIAS_SEMANA_PT = {
    "Monday": "Segunda-feira", "Tuesday": "Terça-feira", "Wednesday": "Quarta-feira",
    "Thursday": "Quinta-feira", "Friday": "Sexta-feira", "Saturday": "Sábado",
    "Sunday": "Domingo",
}
MESES_PT = {
    1: "Janeiro", 2: "Fevereiro", 3: "Março", 4: "Abril", 5: "Maio", 6: "Junho",
    7: "Julho", 8: "Agosto", 9: "Setembro", 10: "Outubro", 11: "Novembro",
    12: "Dezembro",
}

# Paleta e estilo do relatório visual.
COR_DIARIO = "#7C8DB5"
COR_MEDIA_MOVEL = "#C15F3C"
COR_ANOMALIA = "#B03A2E"
COR_TEXTO = "#2E3440"
COR_GRADE = "#DDE1E7"


# --------------------------------------------------------------------------- #
# ETAPA 1 — Ingestão, performance e limpeza
# --------------------------------------------------------------------------- #

def carregar_transacoes(caminho: Path = ARQUIVO_TRANSACOES) -> pd.DataFrame:
    """Lê o CSV de transações respeitando o encoding legado (latin1).

    O arquivo foi gravado pela Engenharia em `latin1`. Ler em UTF-8 levantaria
    `UnicodeDecodeError` ou corromperia acentuação (mojibake), por isso o
    encoding é declarado explicitamente. `dtype` e `parse_dates` são definidos
    na leitura para evitar inferência custosa e conversões posteriores.
    """
    if not caminho.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {caminho}\n"
            "Rode antes: python src/criar_dados.py"
        )

    df = pd.read_csv(
        caminho,
        encoding=ENCODING_LEGADO,
        dtype={
            "id_cliente": "string",
            "estado_cliente": "category",
            "origem": "category",
            "valor": "float64",
        },
    )

    colunas_esperadas = {
        "id_cliente", "data_transacao", "valor", "origem", "estado_cliente",
    }
    faltantes = colunas_esperadas - set(df.columns)
    if faltantes:
        raise ValueError(f"Colunas ausentes no arquivo de transações: {faltantes}")

    return df


def imputar_valores_ausentes(df: pd.DataFrame) -> pd.DataFrame:
    """Imputa os NaN de `valor` pela MEDIANA do respectivo estado.

    Usa `groupby().transform("median")`, que devolve uma Series alinhada ao
    índice original — operação 100% vetorizada, sem laços. A mediana é
    preferida à média por ser robusta a outliers (o dataset tem transações
    de R$ 12.000 convivendo com R$ 50).
    """
    df = df.copy()
    mediana_por_estado = df.groupby("estado_cliente", observed=True)["valor"].transform("median")
    df["valor"] = df["valor"].fillna(mediana_por_estado)

    # Rede de segurança: estado cujo valor seja inteiramente nulo.
    if df["valor"].isna().any():
        df["valor"] = df["valor"].fillna(df["valor"].median())

    return df


def adicionar_rastreabilidade(df: pd.DataFrame) -> pd.DataFrame:
    """Cria a coluna estática `plataforma` para rastreabilidade do pipeline."""
    df = df.copy()
    df["plataforma"] = "Mobile"
    return df


# --------------------------------------------------------------------------- #
# ETAPA 2 — Engenharia de dados e alinhamento temporal
# --------------------------------------------------------------------------- #

def enriquecer_temporalmente(df: pd.DataFrame) -> pd.DataFrame:
    """Converte para datetime64[ns], aplica o fuso e deriva colunas de calendário.

    `tz_localize` é usado (e não `tz_convert`): os timestamps já estão no
    horário local de São Paulo, apenas não carregam essa informação. Isso
    torna o dado inequívoco para junções com outras fontes.
    """
    df = df.copy()

    # `astype` garante a resolução em nanossegundos: a partir do pandas 2.x a
    # inferência pode devolver datetime64[s] ou [us] conforme a string de origem.
    df["data_transacao"] = (
        pd.to_datetime(df["data_transacao"], errors="coerce")
        .astype("datetime64[ns]")
    )
    assert df["data_transacao"].dtype == "datetime64[ns]", "Conversão datetime falhou"

    df["data_transacao"] = df["data_transacao"].dt.tz_localize(
        FUSO_HORARIO,
        ambiguous="NaT",      # horários repetidos no fim do horário de verão
        nonexistent="shift_forward",  # horários inexistentes no início do DST
    )

    # Colunas de calendário via acessor .dt (vetorizado).
    df["dia_semana"] = df["data_transacao"].dt.day_name().map(DIAS_SEMANA_PT)
    df["dia_semana_num"] = df["data_transacao"].dt.dayofweek
    df["mes"] = df["data_transacao"].dt.month
    df["mes_nome"] = df["mes"].map(MESES_PT)
    df["data"] = df["data_transacao"].dt.normalize()  # granularidade diária

    # Categoria ordenada: garante que os meses saiam em ordem cronológica
    # (e não alfabética) em groupby e pivot_table.
    meses_presentes = [MESES_PT[m] for m in sorted(df["mes"].unique())]
    df["mes_nome"] = pd.Categorical(df["mes_nome"], categories=meses_presentes, ordered=True)

    return df


def remover_duplicatas(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Descarta transações duplicadas mantendo a primeira ocorrência.

    A deduplicação considera apenas as colunas de negócio originais — colunas
    derivadas pelo pipeline não devem influenciar o critério de unicidade.
    """
    chave_negocio = [
        "id_cliente", "data_transacao", "valor", "estado_cliente", "origem",
    ]
    antes = len(df)
    df = df.drop_duplicates(subset=chave_negocio, keep="first").reset_index(drop=True)
    return df, antes - len(df)


# --------------------------------------------------------------------------- #
# ETAPA 3 — Operações vetorizadas e filtros bitwise
# --------------------------------------------------------------------------- #

def filtrar_alto_valor_sp_rj(
    df: pd.DataFrame, mes: int = 9, valor_minimo: float = 5_000.0
) -> pd.DataFrame:
    """Filtra transações de setembro, de SP ou RJ, acima de R$ 5.000,00.

    Todas as condições são máscaras booleanas combinadas com operadores
    bitwise (`&` e `|`) de forma vetorizada — nada de `and`/`or` (que exigem
    valor escalar) nem de `iterrows()`. Os parênteses são obrigatórios:
    bitwise tem precedência maior que os operadores de comparação.
    """
    mascara_mes = df["mes"] == mes
    mascara_estado = (df["estado_cliente"] == "SP") | (df["estado_cliente"] == "RJ")
    mascara_valor = df["valor"] > valor_minimo

    mascara_final = mascara_mes & mascara_estado & mascara_valor
    return df.loc[mascara_final].copy()


# --------------------------------------------------------------------------- #
# ETAPA 4 — Cruzamento de dados e agregação
# --------------------------------------------------------------------------- #

def mapear_risco(df: pd.DataFrame, risco_dict: dict[str, str] = RISCO_DICT) -> pd.DataFrame:
    """Atribui o nível de risco de cada cliente via `.map()` (hash lookup O(1))."""
    df = df.copy()
    df["nivel_risco"] = df["id_cliente"].map(risco_dict).fillna("Não Classificado")
    df["nivel_risco"] = pd.Categorical(
        df["nivel_risco"],
        categories=["Baixo", "Médio", "Alto", "Não Classificado"],
        ordered=True,
    ).remove_unused_categories()
    return df


def construir_pivot_risco(df: pd.DataFrame) -> pd.DataFrame:
    """Tabela dinâmica: meses nas linhas, nível de risco nas colunas, soma de `valor`.

    `margins=True` acrescenta a linha e a coluna de subtotais.
    """
    return pd.pivot_table(
        df,
        index="mes_nome",
        columns="nivel_risco",
        values="valor",
        aggfunc="sum",
        margins=True,
        margins_name="TOTAL",
        observed=True,
        fill_value=0,
    )


# --------------------------------------------------------------------------- #
# ETAPA 5 — Detecção estatística de outliers (Z-Score)
# --------------------------------------------------------------------------- #

def calcular_zscore_por_grupo(
    df: pd.DataFrame, coluna: str = "valor", grupo: str = "estado_cliente"
) -> pd.Series:
    """Calcula o Z-Score de `coluna` dentro de cada `grupo`, sem laços.

        Z = (x - mu) / sigma

    `groupby().transform()` difunde a média e o desvio-padrão de cada grupo de
    volta para o índice original, permitindo uma subtração/divisão elemento a
    elemento em NumPy. O Z-Score é calculado POR ESTADO porque o perfil de
    ticket varia regionalmente — um valor normal em SP pode ser anômalo no RS.
    """
    agrupado = df.groupby(grupo, observed=True)[coluna]
    media = agrupado.transform("mean")
    desvio = agrupado.transform("std")

    # np.where evita divisão por zero em grupos de valor constante (sigma = 0).
    zscore = np.where(desvio > 0, (df[coluna] - media) / desvio, 0.0)
    return pd.Series(zscore, index=df.index, name="z_score")


def detectar_anomalias(
    df: pd.DataFrame, limiar: float = LIMIAR_ZSCORE, bilateral: bool = False
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Anexa o Z-Score ao DataFrame e devolve as transações suspeitas.

    Por padrão aplica o critério do enunciado (Z > 2.5), que isola apenas a
    cauda superior — o caso de interesse antifraude. Com `bilateral=True`
    usa |Z| > 2.5, capturando também valores anormalmente baixos.
    """
    df = df.copy()
    df["z_score"] = calcular_zscore_por_grupo(df)

    mascara = (df["z_score"].abs() > limiar) if bilateral else (df["z_score"] > limiar)
    anomalias = df.loc[mascara].sort_values("z_score", ascending=False).copy()

    return df, anomalias


# --------------------------------------------------------------------------- #
# BÔNUS — Consolidação com as cotações diárias
# --------------------------------------------------------------------------- #

def carregar_cotacoes(caminho: Path = ARQUIVO_COTACOES) -> pd.DataFrame:
    """Lê as cotações (UTF-8) e interpola os dias sem fechamento divulgado."""
    df = pd.read_csv(caminho, encoding="utf-8", parse_dates=["data"])
    df = df.sort_values("data").reset_index(drop=True)

    # Interpolação linear no tempo + preenchimento das bordas.
    df["cotacao_usd"] = (
        df.set_index("data")["cotacao_usd"]
        .interpolate(method="time")
        .bfill()
        .ffill()
        .to_numpy()
    )
    return df


def consolidar_com_cotacoes(df: pd.DataFrame, df_cotacoes: pd.DataFrame) -> pd.DataFrame:
    """Junta transações e cotações por dia e converte os valores para USD."""
    chave = df["data"].dt.tz_localize(None)  # remove o fuso só para a junção
    mapa_cotacao = df_cotacoes.set_index("data")["cotacao_usd"]

    df = df.copy()
    df["cotacao_usd"] = chave.map(mapa_cotacao)
    df["cotacao_usd"] = df["cotacao_usd"].ffill().bfill()
    df["valor_usd"] = (df["valor"] / df["cotacao_usd"]).round(2)
    return df


# --------------------------------------------------------------------------- #
# ETAPA 6 — Visualização gráfica orientada a objetos
# --------------------------------------------------------------------------- #

def _formatar_eixo_monetario(ax: plt.Axes) -> None:
    ax.yaxis.set_major_formatter(
        mticker.FuncFormatter(lambda v, _: f"R$ {v:,.0f}".replace(",", "."))
    )


def gerar_grafico_series_temporais(
    df: pd.DataFrame,
    caminho_saida: Path,
    janela: int = JANELA_MEDIA_MOVEL,
) -> pd.DataFrame:
    """Gráfico principal: total diário transacionado + média móvel de 7 dias.

    Construído com a API orientada a objetos do Matplotlib
    (`fig, ax = plt.subplots()`), que dá controle explícito sobre a figura e
    os eixos — abordagem recomendada para código de produção, ao contrário da
    API implícita `plt.plot()`, que depende de estado global.
    """
    serie_diaria = df.groupby(df["data"].dt.tz_localize(None))["valor"].sum().sort_index()
    media_movel = serie_diaria.rolling(window=janela, min_periods=1).mean()

    fig, ax = plt.subplots(figsize=(13, 6.5), dpi=150)

    ax.plot(
        serie_diaria.index, serie_diaria.to_numpy(),
        color=COR_DIARIO, linewidth=1.6, marker="o", markersize=3.5,
        alpha=0.85, label="Valor total transacionado por dia",
    )
    ax.plot(
        media_movel.index, media_movel.to_numpy(),
        color=COR_MEDIA_MOVEL, linewidth=3.0,
        label=f"Média móvel de {janela} dias (tendência suavizada)",
    )
    ax.fill_between(
        serie_diaria.index, 0, serie_diaria.to_numpy(),
        color=COR_DIARIO, alpha=0.10,
    )

    # Eixo Y obrigatoriamente iniciando em zero (evita exagerar variações).
    ax.set_ylim(bottom=0, top=float(serie_diaria.max()) * 1.15)

    ax.set_title(
        "Volume Financeiro Diário e Tendência de 7 Dias",
        fontsize=16, fontweight="bold", color=COR_TEXTO, pad=16, loc="left",
    )
    ax.text(
        0.0, 1.015,
        f"Transações liquidadas no fuso {FUSO_HORARIO} — "
        f"total do período: R$ {serie_diaria.sum():,.2f}".replace(",", "#")
        .replace(".", ",").replace("#", "."),
        transform=ax.transAxes, fontsize=10, color="#6B7280",
    )
    ax.set_xlabel("Data da transação", fontsize=11, color=COR_TEXTO, labelpad=10)
    ax.set_ylabel("Valor transacionado (R$)", fontsize=11, color=COR_TEXTO, labelpad=10)

    _formatar_eixo_monetario(ax)
    ax.xaxis.set_major_locator(mdates.DayLocator(interval=3))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d/%m"))
    ax.grid(axis="y", color=COR_GRADE, linewidth=0.9)
    ax.set_axisbelow(True)
    for lado in ("top", "right"):
        ax.spines[lado].set_visible(False)
    for lado in ("left", "bottom"):
        ax.spines[lado].set_color(COR_GRADE)
    ax.tick_params(colors="#6B7280", labelsize=9)

    ax.legend(
        loc="upper right", frameon=True, framealpha=0.95,
        edgecolor=COR_GRADE, fontsize=10,
    )

    fig.autofmt_xdate(rotation=30, ha="right")
    fig.tight_layout()
    fig.savefig(caminho_saida, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    return pd.DataFrame({"valor_total": serie_diaria, "media_movel_7d": media_movel})


def gerar_painel_complementar(
    df: pd.DataFrame, anomalias: pd.DataFrame, caminho_saida: Path
) -> None:
    """Painel de apoio: exposição por risco, por estado e Z-Scores detectados."""
    fig, axes = plt.subplots(1, 3, figsize=(16, 5), dpi=150)

    # (a) Exposição financeira por nível de risco
    ax = axes[0]
    por_risco = df.groupby("nivel_risco", observed=True)["valor"].sum().sort_values()
    # Cor amarrada à semântica do risco (e não à ordem das barras).
    cores_risco = {"Baixo": "#7FA88A", "Médio": "#D9A441", "Alto": COR_ANOMALIA}
    ax.barh(por_risco.index.astype(str), por_risco.to_numpy(),
            color=[cores_risco.get(str(r), COR_DIARIO) for r in por_risco.index])
    ax.set_title("Exposição por nível de risco", fontsize=12, fontweight="bold",
                 color=COR_TEXTO, loc="left")
    ax.set_xlabel("Valor total (R$)", fontsize=10, color="#6B7280")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v/1e6:.1f}M"))

    # (b) Ticket médio por estado
    ax = axes[1]
    ticket = df.groupby("estado_cliente", observed=True)["valor"].mean().sort_values()
    ax.bar(ticket.index.astype(str), ticket.to_numpy(), color=COR_DIARIO)
    ax.set_title("Ticket médio por estado", fontsize=12, fontweight="bold",
                 color=COR_TEXTO, loc="left")
    ax.set_ylabel("Valor médio (R$)", fontsize=10, color="#6B7280")
    ax.set_ylim(bottom=0)

    # (c) Distribuição dos Z-Scores e o limiar de corte
    ax = axes[2]
    ax.hist(df["z_score"].to_numpy(), bins=40, color=COR_DIARIO, alpha=0.85)
    ax.axvline(LIMIAR_ZSCORE, color=COR_ANOMALIA, linestyle="--", linewidth=2,
               label=f"Limiar Z = {LIMIAR_ZSCORE}")
    ax.set_title(f"Z-Score por estado — {len(anomalias)} anomalias",
                 fontsize=12, fontweight="bold", color=COR_TEXTO, loc="left")
    ax.set_xlabel("Z-Score", fontsize=10, color="#6B7280")
    ax.set_ylabel("Frequência", fontsize=10, color="#6B7280")
    ax.legend(fontsize=9, frameon=False)

    for eixo in axes:
        eixo.grid(axis="both", color=COR_GRADE, linewidth=0.7, alpha=0.6)
        eixo.set_axisbelow(True)
        for lado in ("top", "right"):
            eixo.spines[lado].set_visible(False)
        eixo.tick_params(colors="#6B7280", labelsize=9)

    fig.suptitle("Painel de Apoio — Risco, Regionalidade e Anomalias",
                 fontsize=15, fontweight="bold", color=COR_TEXTO, x=0.01, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(caminho_saida, bbox_inches="tight", facecolor="white")
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Orquestração
# --------------------------------------------------------------------------- #

def _moeda(valor: float) -> str:
    return f"R$ {valor:,.2f}".replace(",", "#").replace(".", ",").replace("#", ".")


def _titulo(texto: str) -> None:
    print(f"\n{'=' * 78}\n{texto}\n{'=' * 78}")


def executar_pipeline() -> dict[str, object]:
    """Executa o pipeline completo e grava os artefatos em `output/`."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # --- ETAPA 1 -----------------------------------------------------------
    _titulo("ETAPA 1 — INGESTÃO, PERFORMANCE E LIMPEZA")
    df = carregar_transacoes()
    print(f"Registros carregados .............. {len(df):,}".replace(",", "."))
    print(f"Encoding aplicado ................. {ENCODING_LEGADO}")
    nulos = int(df["valor"].isna().sum())
    print(f"Valores nulos em 'valor' .......... {nulos}")

    medianas = df.groupby("estado_cliente", observed=True)["valor"].median()
    df = imputar_valores_ausentes(df)
    print("Medianas usadas na imputação ...... "
          + " | ".join(f"{uf}: {_moeda(v)}" for uf, v in medianas.items()))
    print(f"Nulos remanescentes ............... {int(df['valor'].isna().sum())}")

    df = adicionar_rastreabilidade(df)
    print(f"Coluna 'plataforma' criada ........ {df['plataforma'].unique().tolist()}")

    # --- ETAPA 2 -----------------------------------------------------------
    _titulo("ETAPA 2 — ENGENHARIA DE DADOS E ALINHAMENTO TEMPORAL")
    df = enriquecer_temporalmente(df)
    print(f"dtype de 'data_transacao' ......... {df['data_transacao'].dtype}")
    print(f"Janela do dataset ................. "
          f"{df['data_transacao'].min():%d/%m/%Y %H:%M} a "
          f"{df['data_transacao'].max():%d/%m/%Y %H:%M}")
    print(f"Colunas de calendário ............. dia_semana, mes, mes_nome")

    df, removidas = remover_duplicatas(df)
    print(f"Duplicatas descartadas ............ {removidas} (mantida a 1ª ocorrência)")
    print(f"Registros únicos .................. {len(df):,}".replace(",", "."))

    # --- ETAPA 3 -----------------------------------------------------------
    _titulo("ETAPA 3 — OPERAÇÕES VETORIZADAS E FILTROS BITWISE")
    df_filtrado = filtrar_alto_valor_sp_rj(df)
    print("Filtro: mês == 9  &  (SP | RJ)  &  valor > 5.000")
    print(f"Transações selecionadas ........... {len(df_filtrado):,}".replace(",", "."))
    print(f"Montante filtrado ................. {_moeda(df_filtrado['valor'].sum())}")
    print(f"Participação no total ............. "
          f"{df_filtrado['valor'].sum() / df['valor'].sum():.1%}")
    print("\nAmostra:")
    print(df_filtrado[["id_cliente", "data_transacao", "estado_cliente", "valor"]]
          .head(5).to_string(index=False))

    # --- ETAPA 4 -----------------------------------------------------------
    _titulo("ETAPA 4 — CRUZAMENTO DE DADOS (.map) E AGREGAÇÃO (pivot_table)")
    df = mapear_risco(df)
    print("Distribuição de clientes por risco:")
    print(df.groupby("nivel_risco", observed=True)["id_cliente"]
          .nunique().to_string())

    pivot = construir_pivot_risco(df)
    print("\nTabela dinâmica — soma de 'valor' por mês x nível de risco "
          "(com subtotais):")
    print(pivot.map(lambda v: f"{v:,.2f}".replace(",", "#")
                    .replace(".", ",").replace("#", ".")).to_string())

    # --- ETAPA 5 -----------------------------------------------------------
    _titulo("ETAPA 5 — DETECÇÃO ESTATÍSTICA DE OUTLIERS (Z-SCORE POR ESTADO)")
    df, anomalias = detectar_anomalias(df)
    print(f"Critério .......................... Z > {LIMIAR_ZSCORE} "
          f"(cauda superior, por estado)")
    print(f"Transações analisadas ............. {len(df):,}".replace(",", "."))
    print(f"Anomalias detectadas .............. {len(anomalias):,} "
          f"({len(anomalias)/len(df):.2%} da base)".replace(",", "."))
    if not anomalias.empty:
        print(f"Montante sob suspeita ............. {_moeda(anomalias['valor'].sum())}")
        print(f"Z-Score máximo .................... {anomalias['z_score'].max():.3f}")
        print("\nTop 5 anomalias:")
        print(anomalias[["id_cliente", "data_transacao", "estado_cliente",
                         "nivel_risco", "valor", "z_score"]]
              .head(5).to_string(index=False))

    # --- BÔNUS -------------------------------------------------------------
    _titulo("BÔNUS — CONSOLIDAÇÃO COM AS COTAÇÕES DIÁRIAS")
    if ARQUIVO_COTACOES.exists():
        cotacoes = carregar_cotacoes()
        df = consolidar_com_cotacoes(df, cotacoes)
        print(f"Dias de cotação carregados ........ {len(cotacoes)} "
              f"(2 lacunas interpoladas)")
        print(f"Cotação média do período .......... "
              f"US$ 1,00 = {_moeda(cotacoes['cotacao_usd'].mean())}")
        print(f"Volume total convertido ........... US$ "
              + f"{df['valor_usd'].sum():,.2f}".replace(",", "#")
              .replace(".", ",").replace("#", "."))
    else:
        print("Arquivo de cotações ausente — etapa ignorada.")

    # --- ETAPA 6 -----------------------------------------------------------
    _titulo("ETAPA 6 — RELATÓRIO VISUAL (MATPLOTLIB ORIENTADO A OBJETOS)")
    grafico_principal = OUTPUT_DIR / "grafico_serie_temporal.png"
    serie = gerar_grafico_series_temporais(df, grafico_principal)
    print(f"Gráfico principal salvo ........... {grafico_principal.name}")

    painel = OUTPUT_DIR / "painel_complementar.png"
    gerar_painel_complementar(df, anomalias, painel)
    print(f"Painel complementar salvo ......... {painel.name}")

    # --- Artefatos ---------------------------------------------------------
    df.to_csv(OUTPUT_DIR / "transacoes_tratadas.csv", index=False, encoding="utf-8")
    df_filtrado.to_csv(OUTPUT_DIR / "transacoes_filtradas_sp_rj.csv",
                       index=False, encoding="utf-8")
    pivot.to_csv(OUTPUT_DIR / "pivot_risco_por_mes.csv", encoding="utf-8")
    anomalias.to_csv(OUTPUT_DIR / "anomalias_zscore.csv", index=False, encoding="utf-8")
    serie.to_csv(OUTPUT_DIR / "serie_diaria_media_movel.csv", encoding="utf-8")

    _titulo("PIPELINE CONCLUÍDO")
    for arquivo in sorted(OUTPUT_DIR.iterdir()):
        print(f"  • output/{arquivo.name}")

    return {
        "transacoes": df,
        "filtradas": df_filtrado,
        "pivot": pivot,
        "anomalias": anomalias,
        "serie_diaria": serie,
    }


if __name__ == "__main__":
    executar_pipeline()
