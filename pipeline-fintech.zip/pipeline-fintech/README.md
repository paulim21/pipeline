# Pipeline de Análise de Transações Financeiras — Fintech

Pipeline de dados de ponta a ponta que **ingere, limpa, transforma, consolida e
analisa** logs brutos de transações financeiras e cotações, produzindo um
relatório visual com métricas de desempenho e **detecção estatística de
anomalias** (Z-Score por estado).

Todo o processamento é **vetorizado** (pandas/NumPy) — não há um único laço
`for` percorrendo linhas do DataFrame.

---

## Sumário

- [Resultados](#resultados)
- [Estrutura do repositório](#estrutura-do-repositório)
- [Como executar](#como-executar)
- [Requisitos do exercício × implementação](#requisitos-do-exercício--implementação)
- [Decisões técnicas](#decisões-técnicas)
- [Testes](#testes)

---

## Resultados

Execução sobre a base gerada (`seed=42`): **1.015 registros brutos → 1.000
transações únicas**, R$ 2.812.050,00 movimentados entre 01/09 e 12/10/2026.

| Métrica | Valor |
|---|---|
| Registros brutos ingeridos | 1.015 |
| Valores nulos imputados (mediana por estado) | 54 |
| Duplicatas descartadas | 15 |
| Transações SP/RJ > R$ 5.000 em setembro | 72 (R$ 616.500,00 — 21,9% do total) |
| Anomalias detectadas (Z > 2,5) | 46 (4,60% da base — R$ 552.000,00) |
| Z-Score máximo observado | 3,052 |

### Gráfico principal — volume diário e média móvel de 7 dias

![Volume financeiro diário e tendência de 7 dias](output/grafico_serie_temporal.png)

A linha fina mostra o total transacionado a cada dia; a linha grossa é a média
móvel de 7 dias, que remove o ruído diário e revela a tendência. O eixo Y começa
em zero (`ax.set_ylim(bottom=0)`), evitando a distorção visual típica de eixos
truncados.

### Painel de apoio — risco, regionalidade e anomalias

![Painel de apoio](output/painel_complementar.png)

### Tabela dinâmica (soma de `valor` por mês × nível de risco, com subtotais)

| mes_nome | Baixo | Médio | Alto | **TOTAL** |
|---|---:|---:|---:|---:|
| Setembro | 947.550,00 | 319.450,00 | 815.800,00 | **2.082.800,00** |
| Outubro | 272.700,00 | 158.350,00 | 298.200,00 | **729.250,00** |
| **TOTAL** | **1.220.250,00** | **477.800,00** | **1.114.000,00** | **2.812.050,00** |

---

## Estrutura do repositório

```
pipeline-fintech/
├── src/
│   ├── criar_dados.py      # gerador dos logs brutos (fornecido pela Engenharia)
│   └── pipeline.py         # pipeline completo: 6 etapas + consolidação bônus
├── tests/
│   └── test_pipeline.py    # 9 testes que validam cada requisito
├── data/                   # dados brutos gerados (não versionados)
├── output/                 # artefatos do relatório (gráficos, CSVs, log)
├── requirements.txt
├── .gitignore
└── README.md
```

### Artefatos gerados em `output/`

| Arquivo | Conteúdo |
|---|---|
| `grafico_serie_temporal.png` | Gráfico principal (volume diário + média móvel) |
| `painel_complementar.png` | Exposição por risco, ticket médio por estado, distribuição de Z-Scores |
| `transacoes_tratadas.csv` | Base final limpa e enriquecida |
| `transacoes_filtradas_sp_rj.csv` | Recorte do filtro bitwise |
| `pivot_risco_por_mes.csv` | Tabela dinâmica com subtotais |
| `anomalias_zscore.csv` | Transações com Z > 2,5 |
| `serie_diaria_media_movel.csv` | Série diária e média móvel |
| `relatorio_execucao.txt` | Log completo da última execução |

---

## Como executar

Requer **Python 3.10+**.

```bash
# 1. Clonar o repositório
git clone https://github.com/<seu-usuario>/pipeline-fintech.git
cd pipeline-fintech

# 2. (Opcional) Criar um ambiente virtual
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Instalar dependências
pip install -r requirements.txt

# 4. Gerar os dados brutos
python src/criar_dados.py

# 5. Rodar o pipeline
python src/pipeline.py
```

O pipeline imprime um relatório etapa a etapa no console e grava todos os
artefatos em `output/`.

---

## Requisitos do exercício × implementação

### 1. Ingestão, performance e limpeza

| Requisito | Onde | Como |
|---|---|---|
| Carregar `transacoes.csv` | `carregar_transacoes()` | `pd.read_csv` com `dtype` explícito (evita inferência custosa) |
| Encoding legado `latin1` | `carregar_transacoes()` | `encoding="latin1"` declarado — ler em UTF-8 causaria `UnicodeDecodeError`/mojibake |
| Imputar NaN pela mediana do estado | `imputar_valores_ausentes()` | `groupby().transform("median")` + `fillna()` |
| Coluna estática `plataforma` | `adicionar_rastreabilidade()` | `df["plataforma"] = "Mobile"` |

```python
mediana_por_estado = df.groupby("estado_cliente", observed=True)["valor"].transform("median")
df["valor"] = df["valor"].fillna(mediana_por_estado)
```

`transform` devolve uma Series alinhada ao índice original — a imputação é
vetorizada, sem merge nem laço.

### 2. Engenharia de dados e alinhamento temporal

```python
df["data_transacao"] = (
    pd.to_datetime(df["data_transacao"], errors="coerce").astype("datetime64[ns]")
)
df["data_transacao"] = df["data_transacao"].dt.tz_localize(
    "America/Sao_Paulo", ambiguous="NaT", nonexistent="shift_forward"
)

df["dia_semana"] = df["data_transacao"].dt.day_name().map(DIAS_SEMANA_PT)
df["mes"]        = df["data_transacao"].dt.month
df["mes_nome"]   = df["mes"].map(MESES_PT)
```

Duplicatas: `drop_duplicates(subset=chave_negocio, keep="first")` — 15 removidas.

### 3. Operações vetorizadas e filtros bitwise

```python
mascara_mes    = df["mes"] == 9
mascara_estado = (df["estado_cliente"] == "SP") | (df["estado_cliente"] == "RJ")
mascara_valor  = df["valor"] > 5_000.0

df_filtrado = df.loc[mascara_mes & mascara_estado & mascara_valor]
```

Apenas operadores **bitwise** (`&`, `|`) sobre máscaras booleanas. `and`/`or`
não funcionam aqui porque exigem um valor-verdade escalar — levantariam
`ValueError: The truth value of a Series is ambiguous`.

### 4. Cruzamento de dados e agregação

```python
df["nivel_risco"] = df["id_cliente"].map(RISCO_DICT).fillna("Não Classificado")

pivot = pd.pivot_table(
    df, index="mes_nome", columns="nivel_risco", values="valor",
    aggfunc="sum", margins=True, margins_name="TOTAL", observed=True, fill_value=0,
)
```

`.map()` faz lookup em hash table (O(1) por elemento). `margins=True` acrescenta
a linha e a coluna de subtotais.

### 5. Detecção estatística de outliers (Z-Score)

$$Z = \frac{x - \mu}{\sigma}$$

```python
agrupado = df.groupby("estado_cliente", observed=True)["valor"]
media  = agrupado.transform("mean")
desvio = agrupado.transform("std")

zscore = np.where(desvio > 0, (df["valor"] - media) / desvio, 0.0)
anomalias = df.loc[df["z_score"] > 2.5]
```

Sem laços: `transform` difunde μ e σ de cada grupo de volta ao índice original e
a conta vira uma operação elemento a elemento em NumPy. `np.where` protege
contra divisão por zero em grupos de valor constante.

### 6. Visualização orientada a objetos (Matplotlib)

```python
fig, ax = plt.subplots(figsize=(13, 6.5), dpi=150)
ax.plot(serie_diaria.index, serie_diaria, label="Valor total transacionado por dia")
ax.plot(media_movel.index, media_movel, label="Média móvel de 7 dias")
ax.set_ylim(bottom=0)
ax.set_title("Volume Financeiro Diário e Tendência de 7 Dias")
ax.legend()
```

A API orientada a objetos (`fig, ax`) dá controle explícito sobre figura e
eixos, ao contrário da API implícita `plt.plot()`, que depende de estado global
— por isso é a recomendada para código de produção.

### Bônus — consolidação com `cotacoes.csv`

As cotações diárias (2 dias sem fechamento divulgado) são **interpoladas no
tempo** e cruzadas com as transações por data, gerando a coluna `valor_usd`:
US$ 534.137,64 no período, a uma cotação média de R$ 5,21.

---

## Decisões técnicas

**Mediana em vez de média na imputação.** A base mistura tickets de R$ 50 e
R$ 12.000; a média seria puxada pelos valores altos, inflando artificialmente as
transações imputadas. A mediana é robusta a outliers.

**`tz_localize`, não `tz_convert`.** Os timestamps já estão no horário local de
São Paulo — falta apenas declarar o fuso. `tz_convert` deslocaria os horários.
Os parâmetros `ambiguous="NaT"` e `nonexistent="shift_forward"` deixam o código
preparado para horário de verão, caso volte a vigorar.

**Z-Score por estado, não global.** O perfil de ticket varia regionalmente; uma
transação normal em SP pode ser anômala no RS. Calcular μ e σ dentro de cada
estado evita que o volume de um estado grande mascare anomalias nos demais.

**Critério `Z > 2,5` (unilateral).** O enunciado define a cauda superior, que é
o caso de interesse antifraude. A função aceita `bilateral=True` para usar
`|Z| > 2,5` e capturar também valores anormalmente baixos.

**Deduplicação por chave de negócio.** O `drop_duplicates` considera apenas as
colunas originais (`id_cliente`, `data_transacao`, `valor`, `estado_cliente`,
`origem`); colunas derivadas pelo pipeline não devem influenciar o critério de
unicidade.

**Nomes de meses e dias traduzidos por dicionário.** Usar `locale` quebraria o
pipeline em containers sem `pt_BR.UTF-8` instalado.

**`matplotlib.use("Agg")`.** Backend não interativo — o pipeline roda igual em
servidor, container ou CI, sem display gráfico.

---

## Testes

Nove testes validam cada requisito do enunciado — incluindo a propriedade
estatística de que o Z-Score tem média 0 e desvio 1 dentro de cada estado.

```bash
python tests/test_pipeline.py
# ou
python -m pytest tests/ -v
```

```
PASSOU  test_coluna_plataforma_estatica
PASSOU  test_datetime_com_fuso_e_colunas_de_calendario
PASSOU  test_duplicatas_removidas_mantendo_primeira
PASSOU  test_filtro_bitwise
PASSOU  test_imputacao_pela_mediana_do_estado
PASSOU  test_leitura_usa_encoding_legado
PASSOU  test_map_de_risco
PASSOU  test_pivot_table_com_margens
PASSOU  test_zscore_por_estado_e_anomalias

9/9 testes aprovados.
```

---

## Stack

`Python 3.10+` · `pandas` · `NumPy` · `Matplotlib`
